# SimplePlus Beamer Theme

This is a **simple** and **clear** beamer theme for academic and scientific presentation.

check out more information at: [SimplePlus Beamer Theme](https://github.com/PM25/SimplePlus-BeamerTheme)